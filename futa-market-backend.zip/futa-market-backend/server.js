const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// ======================
// MongoDB Connection
// ======================
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch(err => console.error("❌ MongoDB Error:", err));

// ======================
// MongoDB Models
// ======================
const SectionSchema = new mongoose.Schema({
  name: String
});
const ProductSchema = new mongoose.Schema({
  title: String,
  price: Number,
  description: String,
  section: { type: mongoose.Schema.Types.ObjectId, ref: "Section" },
  mediaUrl: String,
  available: { type: Boolean, default: true }
});
const AdminSchema = new mongoose.Schema({
  username: String,
  password: String
});

const Section = mongoose.model("Section", SectionSchema);
const Product = mongoose.model("Product", ProductSchema);
const Admin = mongoose.model("Admin", AdminSchema);

// ======================
// File Upload (Images/Videos)
// ======================
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage });

// ======================
// Routes
// ======================

// Sections
app.get("/sections", async (req, res) => {
  const sections = await Section.find();
  res.json(sections);
});
app.post("/sections", async (req, res) => {
  const section = new Section({ name: req.body.name });
  await section.save();
  res.json(section);
});
app.delete("/sections/:id", async (req, res) => {
  await Section.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

// Products
app.get("/products", async (req, res) => {
  const products = await Product.find().populate("section");
  res.json(products);
});
app.post("/products", async (req, res) => {
  const product = new Product(req.body);
  await product.save();
  res.json(product);
});
app.put("/products/:id", async (req, res) => {
  const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});
app.delete("/products/:id", async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

// Uploads
app.post("/upload", upload.single("file"), (req, res) => {
  res.json({ url: `/uploads/${req.file.filename}` });
});

// Admin Auth
app.post("/register", async (req, res) => {
  const hashed = await bcrypt.hash(req.body.password, 10);
  const admin = new Admin({ username: req.body.username, password: hashed });
  await admin.save();
  res.json({ message: "Admin registered" });
});
app.post("/login", async (req, res) => {
  const admin = await Admin.findOne({ username: req.body.username });
  if (!admin) return res.status(400).json({ error: "Invalid user" });
  const valid = await bcrypt.compare(req.body.password, admin.password);
  if (!valid) return res.status(400).json({ error: "Invalid password" });
  const token = jwt.sign({ id: admin._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
  res.json({ token });
});

// ======================
// Start Server
// ======================
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));